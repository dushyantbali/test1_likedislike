// DiscussionBoard.js
import React, { useState } from 'react';

const DiscussionBoard = () => {
  // Simulate fetching discussions (could be from an API or a database)
  const entries = [
    { id: 1, content: "What is the future of React?" },
    { id: 2, content: "Should developers learn TypeScript?" },
    { id: 3, content: "How can we improve performance in React?" },
  ];

  return (
    <div>
      <h1>Discussion Board</h1>
      {entries.map((entry) => (
        <DiscussionEntry key={entry.id} content={entry.content} />
      ))}
    </div>
  );
};

const DiscussionEntry = ({ content }) => {
  // Track like/dislike count for each entry
  const [count, setCount] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);

  // Handle Like button click
  const handleLike = () => {
    if (selectedOption !== 'like') {
      setSelectedOption('like');
      setCount(count + 1); // Increment count for Like
    }
  };

  // Handle Dislike button click
  const handleDislike = () => {
    if (selectedOption !== 'dislike') {
      setSelectedOption('dislike');
      setCount(count - 1); // Decrement count for Dislike
    }
  };

  return (
    <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ddd' }}>
      <p>{content}</p>
      <div>
        <label>
          <input 
            type="radio" 
            name={`reaction-${content}`} 
            checked={selectedOption === 'like'} 
            onChange={handleLike} 
          />
          Like
        </label>
        <span style={{ margin: '0 10px' }}>{count}</span> {/* Display the current count */}
        <label>
          <input 
            type="radio" 
            name={`reaction-${content}`} 
            checked={selectedOption === 'dislike'} 
            onChange={handleDislike} 
          />
          Dislike
        </label>
      </div>
    </div>
  );
};

export default DiscussionBoard;
