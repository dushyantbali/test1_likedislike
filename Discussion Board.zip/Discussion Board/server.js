const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/discussion_board', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
    console.log('Connected to the database');
});

// Define routes here

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
import React, { useState } from 'react';

// Main Discussion Board Component
const DiscussionBoard = () => {
  // Simulating discussion entries. This could be dynamic based on actual data.
  const entries = [
    { id: 1, content: "This is the first discussion topic!" },
    { id: 2, content: "Here's a discussion about React.js." },
    { id: 3, content: "Let's talk about the future of web development." },
  ];

  return (
    <div>
      <h1>Discussion Board</h1>
      {entries.map((entry) => (
        <DiscussionEntry key={entry.id} content={entry.content} />
      ))}
    </div>
  );
};

const DiscussionEntry = ({ content }) => {
  const [count, setCount] = useState(0); // Track the like/dislike count
  const [selectedOption, setSelectedOption] = useState(null); // Track if Like/Dislike is selected

  // Handle like button click
  const handleLike = () => {
    if (selectedOption !== 'like') {
      setSelectedOption('like');
      setCount(count + 1); // Increment count for Like
    }
  };

  // Handle dislike button click
  const handleDislike = () => {
    if (selectedOption !== 'dislike') {
      setSelectedOption('dislike');
      setCount(count - 1); // Decrement count for Dislike
    }
  };

  return (
    <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ddd' }}>
      <p>{content}</p>
      <div>
        <label>
          <input 
            type="radio" 
            name={`reaction-${content}`} 
            checked={selectedOption === 'like'} 
            onChange={handleLike} 
          />
          Like
        </label>
        <span style={{ margin: '0 10px' }}>{count}</span> {/* Show current count */}
        <label>
          <input 
            type="radio" 
            name={`reaction-${content}`} 
            checked={selectedOption === 'dislike'} 
            onChange={handleDislike} 
          />
          Dislike
        </label>
      </div>
    </div>
  );
};

export default Discussion_Board;

import React from 'react';
import ReactDOM from 'react-dom';
import Discussion_Board from './DiscussionBoard'; // Import the DiscussionBoard component

const App = () => {
  return (
    <div>
      <Discussion_Board />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
